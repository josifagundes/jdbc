/**
 * 
 */
/**
 * 
 */
module jdbc {
	requires java.sql;
}